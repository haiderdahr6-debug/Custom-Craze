/* ===========================================================
   Custom Craze — shared script
   - WhatsApp number (change in ONE place if it ever changes)
   - Mobile menu toggle
   - "Order on WhatsApp" buttons on product cards
   - Order form -> builds WhatsApp message
   =========================================================== */

// ⬇️ Your WhatsApp business number (country code, no + or spaces)
const WHATSAPP_NUMBER = "923042798721";

// ---------- Mobile menu ----------
document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      nav.classList.toggle("open");
    });
  }

  // ---------- Quick "Order on WhatsApp" buttons (data-product / data-price) ----------
  document.querySelectorAll(".order-wa-btn[data-product]").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      const product = btn.getAttribute("data-product") || "this item";
      const price = btn.getAttribute("data-price") || "";
      const message =
        "Hello Custom Craze! I want to order:\n" +
        "🛍️ Product: " + product + "\n" +
        (price ? "💰 Price: " + price + "\n" : "") +
        "💵 Payment: Cash on Delivery\n\n" +
        "My name: \nMy phone: \nMy full address: \n\nPlease confirm my order. Thank you!";
      openWhatsApp(message);
    });
  });

  // ---------- Full order form ----------
  const orderForm = document.getElementById("orderForm");
  if (orderForm) {
    orderForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const name = document.getElementById("ofName").value.trim();
      const phone = document.getElementById("ofPhone").value.trim();
      const address = document.getElementById("ofAddress").value.trim();
      const city = document.getElementById("ofCity").value.trim();
      const product = document.getElementById("ofProduct").value;
      const qty = document.getElementById("ofQty").value.trim() || "1";
      const notes = document.getElementById("ofNotes").value.trim();

      if (!name || !phone || !address || !city) {
        showToast("Please fill in your name, phone, address and city first.");
        return;
      }

      const message =
        "🆕 NEW ORDER — Custom Craze website\n\n" +
        "👤 Name: " + name + "\n" +
        "📞 Phone: " + phone + "\n" +
        "🏠 Address: " + address + "\n" +
        "🏙️ City: " + city + "\n" +
        "🎁 Product: " + product + "\n" +
        "🔢 Quantity: " + qty + "\n" +
        (notes ? "📝 Notes: " + notes + "\n" : "") +
        "💵 Payment: Cash on Delivery\n\n" +
        "Please confirm this order. Thank you!";

      openWhatsApp(message);
      showToast("Opening WhatsApp... please tap Send to confirm your order 📲");
      orderForm.reset();
    });
  }

  // footer year
  document.querySelectorAll(".year").forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });
});

function openWhatsApp(message) {
  const url = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(message);
  window.open(url, "_blank");
}

function showToast(text) {
  let toast = document.querySelector(".toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = text;
  toast.classList.add("show");
  setTimeout(function () {
    toast.classList.remove("show");
  }, 4000);
}
