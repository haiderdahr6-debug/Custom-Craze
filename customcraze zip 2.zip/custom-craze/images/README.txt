Product photos — kahan se aa rahi hain (where the photos come from)
======================================================================

Aapne kaha tha ke photos khud add nahi karni, is liye maine har product
ki photo seedha customcraze.online se link kar di hai (hotlink) — jo
photo abhi us site par live hai, wahi yahan bhi dikhegi. Koi file
upload nahi karni padi.

⚠️ Isme ek chhoti si baat samjhiye:
- Ye photos CustomCraze.online ke server par hi rehti hain — is naye
  GitHub Pages site par copy nahi hui.
- Agar customcraze.online band ho jaye, ya us file ka naam/location
  badal jaye, to is site par wo tasveer dikhna band ho jayegi.
- Agar future mein aap apni khud ki photos is site par permanently
  save karna chahen, to bas:
    1. Photo is "images" folder mein daal dein (e.g. images/mug1.jpg)
    2. HTML file mein us product ki <img src="..."> line mein
       customcraze.online wala link hata kar "images/mug1.jpg" likh dein

Logo (images/logo.webp) already is folder mein permanently saved hai —
wo link nahi hai, woh hamesha chalega.
