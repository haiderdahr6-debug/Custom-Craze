# Custom Craze — Website

Light, professional website for **Custom Craze** (personalised photo frames,
mugs, t-shirts & gifts). Pure HTML/CSS/JS — no build tools needed, works
directly on **GitHub Pages**.

## Pages
- `index.html` — Home (banner, categories, best sellers, how it works)
- `frames.html` — Photo Frames
- `mugs.html` — Mugs
- `tshirts.html` — T-Shirts
- `gifts.html` — Occasions & Gifts (Wedding/Nikkah, Birthday, Anniversary)
- `order.html` — Order form (Cash on Delivery → sends order to your WhatsApp)

## How orders / notifications work
There's no paid backend — so every order goes straight to **your WhatsApp**:
- Each product has an "Order on WhatsApp" button.
- The `order.html` form builds a full order message (name, phone, address,
  product, qty, notes) and opens WhatsApp with it pre-filled.
- The customer just taps **Send** — you get it instantly as a WhatsApp
  message. That message *is* your order notification.

Your WhatsApp number is set in **one place**: `js/main.js`, line:
```js
const WHATSAPP_NUMBER = "923042798721";
```
Change it there if your number ever changes — every page updates automatically.

## Go live on GitHub Pages (step by step)

1. Go to **github.com** → click **+** (top right) → **New repository**.
   - Name it `custom-craze` (or anything you like).
   - Keep it **Public**. Don't add a README (you already have one).
   - Click **Create repository**.

2. On the new repo's page, click **"uploading an existing file"**.
   - Drag in **all the files and folders** from this `custom-craze` folder
     (index.html, frames.html, mugs.html, tshirts.html, gifts.html,
     order.html, README.md, the whole `css/`, `js/` and `images/` folders).
   - Scroll down, click **Commit changes**.

3. Go to the repo's **Settings** tab → **Pages** (left sidebar).
   - Under "Build and deployment" → Source: **Deploy from a branch**.
   - Branch: **main**, folder: **/ (root)** → **Save**.

4. Wait ~1 minute, refresh the Pages settings tab — you'll see a green box
   with your live link, something like:
   `https://<your-username>.github.io/custom-craze/`

That link is your live website — share it anywhere (Instagram bio,
WhatsApp status, etc).

## Product content & photos
All product names, prices, and photos are pulled from your live store at
customcraze.online (frames, mugs, t-shirt, cushions, wedding/birthday gifts),
so it matches what you already sell. Photos are currently **hotlinked**
from customcraze.online — see `images/README.txt` for what that means and
how to switch to your own saved copies later if you ever want to.

## Editing text / prices later
Everything is plain HTML — open any `.html` file in a text editor (even
GitHub's own online editor: open the file in your repo → pencil ✏️ icon),
find the text or price you want to change, edit it, and commit. No
coding knowledge needed beyond careful copy-paste.
