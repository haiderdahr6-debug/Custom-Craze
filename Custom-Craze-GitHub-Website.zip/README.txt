CUSTOM CRAZE — GITHUB PAGES WEBSITE

Files:
- index.html: Home page
- frames.html: Photo frames page
- mugs.html: Mugs page
- tshirts.html: T-shirts page
- gifts.html: Occasions and gifts page
- order.html: Order form page
- css/style.css: Design and layout for all pages
- js/main.js: Mobile menu and WhatsApp order functionality
- images/logo.webp: Website logo

IMPORTANT:
1. Upload this complete folder's CONTENTS to the root of your GitHub repository.
2. Keep the css, js, and images folders with these exact names.
3. Keep index.html in the repository root.
4. Product photos are linked from customcraze.online, so those photos depend on that website remaining online.
5. The order form and product buttons open WhatsApp using the number configured in js/main.js.

To publish:
GitHub repository -> Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
